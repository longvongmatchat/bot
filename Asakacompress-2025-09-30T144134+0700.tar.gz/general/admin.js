const Discord = require("discord.js");

exports.run = async (client, message, args) => {

const ayarlar = require('../ayarlar.json');
var room = ayarlar.commandroom;

if (message.channel.id != room) {
	return;
  }

// Example command
if(!args[0]) {
	const embed1 = new Discord.MessageEmbed()
	.setColor('RANDOM')
	.setTitle('🚀 **Nova** 🚀')
	.setDescription("**INFO ADMIN** \n`Tên : Nguyen Quang Hai` \n`Năm sinh : 200x` \n`Sở thích : Thich suc, nghe nhac, ...`\n `Contacts : hai588847@gmail.com` \n `Facebook : `")
	.setFooter('Copyright: novadz#0250', client.user.avatarURL)
    message.channel.send(embed1);
	return;
	}

}

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['admin'],
  permLevel: 0
}

exports.help = {
  name: 'admin',
  description: 'Anhhaidzvcl1',
  usage: 'admin'
}
