const Discord = require("discord.js");

exports.run = async (client, message, args) => {

const ayarlar = require('../ayarlar.json');
var room = ayarlar.commandroom;

if (message.channel.id != room) {
	return;
  }

// Example command
if(!args[0]) {
	const embed1 = new Discord.MessageEmbed()
	.setColor('RANDOM')
	.setTitle('🚀 **Arcues Command** 🚀')
	.setDescription("**Nova dep zai tặc co s1 VN** \n **Hãy dùng BOT 1 cách nghiêm túc, đặc biệt cấm SPAM**\n`Anh em dùng lệnh .methods để xem all Methods DDOS : .<methods> + <url>`\n`Demo : HTTPS-GO+ <url>`\n `Chúc all sài bot vui vẻ, có tiền sẽ up thêm methods»`")
	message.channel.send(embed1);
	return;
	}

}

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['command'],
  permLevel: 0
}

exports.help = {
  name: 'command',
  description: 'Nova',
  usage: 'command'
}
